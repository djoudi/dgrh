<?php

namespace App\Http\Controllers;



class LiveController extends Controller
{
    public function index()
    {
        return view('dgrh.live');
    }
}