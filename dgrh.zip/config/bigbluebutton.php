<?php

return [
    /*
     * Bigbluebutton server secret
     */
    'BBB_SECURITY_SALT'   => env('BBB_SECURITY_SALT', ''),
    'BBB_SERVER_BASE_URL' => env('BBB_SERVER_BASE_URL', ''),
];
