
<div class="card">

                <div class="card-header card-header-info text-right">
                  <h4 class="card-title">إضافة مستخدم</h4>
                  <p class="card-category">إضافة مستغدم مع تحديد المجموعة</p>
                </div>
                <div class="card-body">
                  <form wire:submit.prevent="store">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating" for="name">إسم المستخدم</label>
                          <input type="text" wire:model.lazy="name" class="form-control"  id="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="name-error" class="error" for="name"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                      </div>

                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">البريد الإلكتروني</label>
                          <input type="email" wire:model.lazy="email" class="form-control">
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="email-error" class="error" for="email"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">الإسم</label>
                          <input type="text" wire:model.lazy="first_name" class="form-control">
                           <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="first_name-error" class="error" for="first_name"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">اللقب</label>
                          <input type="text" wire:model.lazy="last_name" class="form-control">
                           <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="last_name-error" class="error" for="last_name"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">رقم الهاتف</label>
                          <input type="text" wire:model.lazy="mobile" class="form-control">
                           <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="mobile-error" class="error" for="mobile"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>

                         <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">الرتبة</label>
                          <input type="text" wire:model.lazy="grade" class="form-control">
                          <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <label id="grade-error" class="error" for="grade"><?php echo e($message); ?></label> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">

                      <div class="col-md-6">
                        <div class="form-group">
                          <select wire:model="w" class="form-control">
                              <option value="" class="bmd-label-floating">الولاية</option>
                             <?php $__currentLoopData = $wilaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option  value="<?php echo $w->id; ?>"  ><?php echo $w->name; ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>

                        </div>
                      </div>
                      <div class="col-md-6">
                           <div class="form-group">
                          <select wire:model="r" class="form-control">
                              <option value="" class="bmd-label-floating">المجموعة</option>
                              <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo $r->id; ?>" ><?php echo $r->name; ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                         
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                         <div class="form-group">
                          <label class="bmd-label-floating">كلمة المرور</label>
                          <input type="password" wire:model.lazy="password" class="form-control">
                        </div>

                      </div>
                         <div class="col-md-6">
                         <div class="form-group">
                          <label class="bmd-label-floating">تأكيد كلمة المرور</label>
                          <input type="password" wire:model.lazy="password" class="form-control">
                        </div>

                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">إضافة</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>

<?php /**PATH C:\Users\Djoudi\app\dgrh\resources\views/livewire/create-user.blade.php ENDPATH**/ ?>