<div>
<button  wire:click="showForm"  class="btn btn-info btn-lg btn-round"><i class="material-icons">person_add</i>    إضافة مستخدم</button>

<?php if($isclickAdd): ?>
     <?php if($updateMode): ?>
     <?php echo $__env->make('livewire.update-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
          <?php echo $__env->make('livewire.create-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endif; ?>
<?php endif; ?>

              <div class="card" wire:key="list-user">
                <div class="card-header card-header-tabs card-header-info">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <span class="nav-tabs-title">المجموعات</span>
                      <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                          <a class="nav-link <?php echo e($user_role=="Admin" ? 'active':''); ?>"  data-toggle="tab" wire:click="user_admin">
                            <i class="material-icons">settings</i> Admin
                            <div class="ripple-container"></div>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link <?php echo e($user_role=="miclat" ? 'active':''); ?>"  data-toggle="tab" wire:click="user_miclat">
                            <i class="material-icons">account_balance</i> MICLAT
                            <div class="ripple-container"></div>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link <?php echo e($user_role=="wilaya" ? 'active':''); ?>"  data-toggle="tab" wire:click="user_wilaya">
                            <i class="material-icons">location_city</i> WILAYA
                            <div class="ripple-container"></div>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="tab-content" wire:key="tab">
               <?php if($user_role=='Admin'): ?>
                    <div class="tab-pane <?php echo e($user_role=="Admin" ? 'active':''); ?>" id="admin" wire:key="admin">
                       <h3>Admin</h3>
                      <table class="table">
                        <tbody>
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>

                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td><?php echo e($u->mobile); ?></td>
                            <td><?php echo e($u->wilaya->name); ?></td>
                            <td class="td-actions text-right">
                              <button type="button" rel="tooltip" title="Edit Task"
                              class="btn btn-primary btn-link btn-sm" >
                                <i class="material-icons">edit</i>
                              </button>
                              <button type="button" rel="tooltip" title="Remove"
                              class="btn btn-danger btn-link btn-sm"
                              onclick="confirm('هل أنت متأكد ؟') || event.stopImmediatePropagation()"
                              wire:click="destroy(<?php echo e($u->id); ?>)"

                              >
                                <i class="material-icons">close</i>
                              </button>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                      </table>
                    </div>
                <?php elseif($user_role=='miclat'): ?>
                    <div class="tab-pane <?php echo e($user_role=="miclat" ? 'active':''); ?>" id="miclat" wire:key="miclat">
                       <h3>MICLAT</h3>
                      <table class="table">
                        <tbody>
                         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                              <tr>

                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td><?php echo e($u->mobile); ?></td>
                            <td><?php echo e($u->wilaya->name); ?></td>
                            <td class="td-actions text-right">
                              <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                <i class="material-icons">edit</i>
                              </button>
                              <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                <i class="material-icons">close</i>
                              </button>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                <?php else: ?>
                     <div class="tab-pane <?php echo e($user_role=="wilaya" ? 'active':''); ?>" id="wilaya" wire:key="wilaya">
                         <h3>WILAYA</h3>
                      <table class="table">
                        <tbody>
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>

                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td><?php echo e($u->mobile); ?></td>
                            <td><?php echo e($u->wilaya->name); ?></td>
                            <td class="td-actions text-right">
                              <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                <i class="material-icons">edit</i>
                              </button>
                              <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                <i class="material-icons">close</i>
                              </button>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
               <?php endif; ?>




                   </div>  
                </div>   
              
</div>
<?php /**PATH C:\Users\Djoudi\app\dgrh\resources\views/livewire/users.blade.php ENDPATH**/ ?>