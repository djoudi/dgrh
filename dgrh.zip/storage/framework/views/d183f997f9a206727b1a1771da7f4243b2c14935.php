<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('users', [])->dom;
} elseif ($_instance->childHasBeenRendered('P9aHGEv')) {
    $componentId = $_instance->getRenderedChildComponentId('P9aHGEv');
    $componentTag = $_instance->getRenderedChildComponentTagName('P9aHGEv');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('P9aHGEv');
} else {
    $response = \Livewire\Livewire::mount('users', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('P9aHGEv', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dgrh.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Djoudi\app\dgrh\resources\views/dgrh/user.blade.php ENDPATH**/ ?>