<?php return array (
  'create-user' => 'App\\Http\\Livewire\\CreateUser',
  'lives' => 'App\\Http\\Livewire\\Lives',
  'update-user' => 'App\\Http\\Livewire\\UpdateUser',
  'users' => 'App\\Http\\Livewire\\Users',
);