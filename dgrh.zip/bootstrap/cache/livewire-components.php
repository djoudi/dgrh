<?php return array (
  'change-password' => 'App\\Http\\Livewire\\ChangePassword',
  'lives' => 'App\\Http\\Livewire\\Lives',
  'users' => 'App\\Http\\Livewire\\Users',
);