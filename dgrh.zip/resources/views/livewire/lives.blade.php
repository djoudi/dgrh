<div>

    <button type="button" wire:click="create" id="" class="btn btn-primary" btn-lg btn-block">إنشاء قاعة إجتماعات</button>
     <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">نظام التخاطب عن بعد</h4>
                  <p class="card-category">إجتماعات الجماعات المحلية</p>
                </div>
                <div class="card-body table-responsive">
                  <table class="table table-hover">
                    <thead class="text-info">
                      <th>إسم القاعة</th>
                      <th>الوقت</th>
                      <th>الدخول للقاعة</th>
                    </thead>
                    <tbody>
                      <tr>
                        <td>الإدارات المركزية</td>
                        <td>14:15</td>
                        <td>
<a href="/" class=" text-danger text-center"><span class="material-icons">
wifi_tethering
</span></a>

                        </td>
                      </tr>

                    </tbody>
                  </table>
                </div>
              </div>
</div>
